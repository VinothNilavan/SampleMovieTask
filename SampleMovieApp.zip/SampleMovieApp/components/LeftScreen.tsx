import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';

interface Movie {
  id: number;
  title: string;
  year: number;
  genre: string;
  director: string;
  rating: number;
  description: string;
  cast: string[];
  image: string;
}

interface LeftScreenProps {
  movies: Movie[];
  selectedMovie: Movie | null;
  onSelectMovie: (movie: Movie) => void;
}

const LeftScreen: React.FC<LeftScreenProps> = ({
  movies,
  selectedMovie,
  onSelectMovie,
}) => {
  const renderMovieItem = ({ item }: { item: Movie }) => {
    const isSelected = selectedMovie?.id === item.id;

    return (
      <TouchableOpacity
        style={[
          styles.movieItem,
          isSelected && styles.selectedMovieItem,
        ]}
        onPress={() => onSelectMovie(item)}
      >
        <Image
          source={{ uri: item.image }}
          style={styles.movieThumbnail}
          resizeMode="cover"
        />
        <View style={styles.movieInfo}>
          <Text style={[styles.movieTitle, isSelected && styles.selectedText]}>
            {item.title}
          </Text>
          <Text style={[styles.movieYear, isSelected && styles.selectedText]}>
            {item.year} • {item.rating}/10
          </Text>
          <Text
            style={[styles.movieGenre, isSelected && styles.selectedText]}
            numberOfLines={1}
          >
            {item.genre}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Movies</Text>
        <Text style={styles.headerSubtitle}>{movies.length} movies</Text>
      </View>
      <FlatList
        data={movies}
        renderItem={renderMovieItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  listContent: {
    padding: 8,
  },
  movieItem: {
    backgroundColor: '#fff',
    padding: 12,
    marginVertical: 4,
    marginHorizontal: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectedMovieItem: {
    backgroundColor: '#2196F3',
    borderColor: '#1976D2',
  },
  movieThumbnail: {
    width: 80,
    height: 120,
    borderRadius: 6,
    marginRight: 12,
    backgroundColor: '#f0f0f0',
  },
  movieInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  movieTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  movieYear: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  movieGenre: {
    fontSize: 12,
    color: '#999',
  },
  selectedText: {
    color: '#fff',
  },
});

export default LeftScreen;


import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Image,
} from 'react-native';

interface Movie {
  id: number;
  title: string;
  year: number;
  genre: string;
  director: string;
  rating: number;
  description: string;
  cast: string[];
  image: string;
}

interface RightScreenProps {
  selectedMovie: Movie | null;
}

const RightScreen: React.FC<RightScreenProps> = ({ selectedMovie }) => {
  if (!selectedMovie) {
    return (
      <View style={styles.container}>
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>
            Select a movie from the list to view details
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.contentContainer}
      >
        <Image
          source={{ uri: selectedMovie.image }}
          style={styles.movieImage}
          resizeMode="cover"
        />
        <View style={styles.header}>
          <Text style={styles.title}>{selectedMovie.title}</Text>
          <View style={styles.metaContainer}>
            <Text style={styles.year}>{selectedMovie.year}</Text>
            <Text style={styles.separator}>•</Text>
            <Text style={styles.rating}>⭐ {selectedMovie.rating}/10</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Genre</Text>
          <Text style={styles.sectionContent}>{selectedMovie.genre}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Director</Text>
          <Text style={styles.sectionContent}>{selectedMovie.director}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Description</Text>
          <Text style={styles.description}>{selectedMovie.description}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Cast</Text>
          <View style={styles.castContainer}>
            {selectedMovie.cast.map((actor, index) => (
              <View key={index} style={styles.castItem}>
                <Text style={styles.castName}>{actor}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 20,
  },
  movieImage: {
    width: '80%',
    height: 200,
    borderRadius: 12,
    marginBottom: 20,
    backgroundColor: '#f0f0f0',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
  header: {
    marginBottom: 24,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  metaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  year: {
    fontSize: 16,
    color: '#666',
    marginRight: 8,
  },
  separator: {
    fontSize: 16,
    color: '#999',
    marginHorizontal: 8,
  },
  rating: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2196F3',
    marginBottom: 8,
  },
  sectionContent: {
    fontSize: 16,
    color: '#333',
    lineHeight: 24,
  },
  description: {
    fontSize: 16,
    color: '#333',
    lineHeight: 24,
    textAlign: 'justify',
  },
  castContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  castItem: {
    backgroundColor: '#f5f5f5',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  castName: {
    fontSize: 14,
    color: '#333',
  },
});

export default RightScreen;


/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { useState, useEffect } from 'react';
import { StatusBar, StyleSheet, useColorScheme, View } from 'react-native';
import {
  SafeAreaProvider,
} from 'react-native-safe-area-context';
import LeftScreen from './components/LeftScreen';
import RightScreen from './components/RightScreen';
import moviesData from './data/movies.json';

interface Movie {
  id: number;
  title: string;
  year: number;
  genre: string;
  director: string;
  rating: number;
  description: string;
  cast: string[];
  image: string;
}

function App() {
  const isDarkMode = useColorScheme() === 'dark';
  const [movies, setMovies] = useState<Movie[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

  useEffect(() => {
    setMovies(moviesData.movies);
    if (moviesData.movies.length > 0) {
      setSelectedMovie(moviesData.movies[0]);
    }
  }, []);

  const handleSelectMovie = (movie: Movie) => {
    setSelectedMovie(movie);
  };

  return (
    <SafeAreaProvider>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <View style={styles.container}>
        <View style={styles.splitContainer}>
          <View style={styles.leftPanel}>
            <LeftScreen
              movies={movies}
              selectedMovie={selectedMovie}
              onSelectMovie={handleSelectMovie}
            />
          </View>
          <View style={styles.divider} />
          <View style={styles.rightPanel}>
            <RightScreen selectedMovie={selectedMovie} />
          </View>
        </View>
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  splitContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  leftPanel: {
    flex: 1,
    minWidth: 300,
  },
  divider: {
    width: 1,
    backgroundColor: '#e0e0e0',
  },
  rightPanel: {
    flex: 1,
    minWidth: 300,
  },
});

export default App;
